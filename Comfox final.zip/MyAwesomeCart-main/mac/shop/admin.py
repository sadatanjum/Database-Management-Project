from django.contrib import admin
from .models import Product, Order, OrderUpdate, FAQSubmission
# Register your models here.
admin.site.register(Product)
# admin.site.register(Contact)
admin.site.register(Order)
admin.site.register(OrderUpdate)
admin.site.register(FAQSubmission)
from . models import Form
from . models import ProductReview
admin.site.register(Form)
admin.site.register(ProductReview)